<section class="details-menu room-details-section lazyloaded" id="details-menu-section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-10 offset-1 col-lg-8 offset-lg-2 p-0">
                <a class="button" href="https://concierge.mayaresorts.com/dining-menu/ubud-breakfast-menu.html?_ga=2.128971404.1850656978.1658663813-1833862106.1658663813" target="_blank">Breakfast Menu</a>                                                            </div>
        </div>
    </div>
</section>